const express = require("express");

const app = express();
app.use(express.json({ limit: "2mb" }));

const PORT = process.env.PORT || 10000;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const D360_API_KEY = process.env.D360_API_KEY;
const D360_MESSAGES_URL =
  process.env.D360_MESSAGES_URL || "https://waba-v2.360dialog.io/messages";
const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-3.7-flash";

const seen = new Map();
const DEDUPE_MS = 10 * 60 * 1000;

function markSeen(id) {
  const now = Date.now();
  for (const [k, t] of seen) {
    if (now - t > DEDUPE_MS) seen.delete(k);
  }
  if (seen.has(id)) return true;
  seen.set(id, now);
  return false;
}

async function askGemini(text) {
  if (!GEMINI_API_KEY) throw new Error("GEMINI_API_KEY is missing");

  const url =
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_MODEL)}:generateContent`;

  const r = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": GEMINI_API_KEY,
    },
    body: JSON.stringify({
      contents: [{ role: "user", parts: [{ text }] }],
      generationConfig: { maxOutputTokens: 900 },
    }),
  });

  if (!r.ok) {
    const body = await r.text();
    throw new Error(`Gemini ${r.status}: ${body.slice(0, 400)}`);
  }

  const data = await r.json();
  const reply = data?.candidates?.[0]?.content?.parts
    ?.map((p) => p?.text || "")
    .join("")
    .trim();

  return reply || "দুঃখিত, এখন উত্তর তৈরি করা যাচ্ছে না।";
}

async function sendWhatsApp(to, body) {
  if (!D360_API_KEY) throw new Error("D360_API_KEY is missing");

  const r = await fetch(D360_MESSAGES_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "D360-API-KEY": D360_API_KEY,
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to,
      type: "text",
      text: { body: body.slice(0, 4000) },
    }),
  });

  if (!r.ok) {
    const responseText = await r.text();
    throw new Error(`360dialog ${r.status}: ${responseText.slice(0, 400)}`);
  }
}

app.get("/", (req, res) => {
  res.type("html").send(`
    <h2>WhatsApp Gemini Bot is running ✅</h2>
    <p>Webhook path: <code>/webhook</code></p>
    <p>Health: <code>/health</code></p>
  `);
});

app.get("/health", (req, res) => {
  res.json({
    ok: true,
    geminiConfigured: Boolean(GEMINI_API_KEY),
    d360Configured: Boolean(D360_API_KEY),
    webhook: "/webhook",
  });
});

app.post("/webhook", (req, res) => {
  // Acknowledge immediately so 360dialog does not retry unnecessarily.
  res.sendStatus(200);

  queueMicrotask(async () => {
    try {
      const changes = req.body?.entry?.flatMap((e) => e?.changes || []) || [];

      for (const change of changes) {
        const value = change?.value || {};
        const messages = Array.isArray(value.messages) ? value.messages : [];

        for (const msg of messages) {
          if (!msg?.id || markSeen(msg.id)) continue;
          if (msg.type !== "text") continue;

          const text = msg?.text?.body?.trim();
          const from = msg?.from;
          if (!text || !from) continue;

          const reply = await askGemini(text);
          await sendWhatsApp(from, reply);
        }
      }
    } catch (err) {
      console.error(err);
    }
  });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Bot running on port ${PORT}`);
});